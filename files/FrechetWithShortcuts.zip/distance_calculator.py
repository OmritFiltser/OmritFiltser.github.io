import math
ALLOWED_ERROR = 1e-3


# Returns euclidian distance between the 2 given points
def distance(p1, p2):
    return math.hypot(p1[0] - p2[0], p1[1] - p2[1])


# Calculates discrete Frechet distance with DP approach
def discrete_frechet(P, Q):
    n, m = len(P), len(Q)
    dp = [[float('inf')] * m for _ in range(n)]
    dp[0][0] = distance(P[0], Q[0])
    prev = [[(0, 0) for _ in range(m)] for _ in range(n)]

    for i in range(n):
        for j in range(m):
            if i > 0 and j > 0 and dp[i][j] > max(dp[i-1][j-1], distance(P[i], Q[j])):
                dp[i][j] = max(dp[i-1][j-1], distance(P[i], Q[j]))  # jump on both P and Q
                prev[i][j] = (i-1, j-1)
            if i > 0 and dp[i][j] > max(dp[i-1][j], distance(P[i], Q[j])):
                dp[i][j] = max(dp[i-1][j], distance(P[i], Q[j]))  # jump on P
                prev[i][j] = (i-1, j)
            if j > 0 and dp[i][j] > max(dp[i][j-1], distance(P[i], Q[j])):
                dp[i][j] = max(dp[i][j-1], distance(P[i], Q[j]))  # jump on Q
                prev[i][j] = (i, j-1)

    return dp[n-1][m-1], trace_back(prev)

# retraced the best path found
def trace_back(prev):
    curr = (len(prev)-1, len(prev[0])-1)
    trace = [curr]
    while curr != (0, 0):
        curr = prev[curr[0]][curr[1]]
        trace.append(curr)
    trace.reverse()
    return trace



'''
Calculates discrete Frechet distance with shortcuts with binary search and decision algorithm approach
shortcuts are only allowed on the second curve.
'''
def shortcut_discrete_frechet(P, Q):
    n, m = len(P), len(Q)
    path = None

    def decision(threshold):
        nonlocal path
        if distance(P[0], Q[0]) > threshold or distance(P[n-1], Q[m-1]) > threshold:
            return False
        trace = [(0, 0)]
        j = 0
        for i in range(1, n-1):
            while distance(P[i], Q[j]) > threshold:
                j += 1
                if j == m:
                    return False
            trace.append((i, j))
        trace.append((n-1, m-1))
        path = trace
        return True

    low, mid, high = 0, 1, 1

    # find some maximum value for the leash length that is more than the Frechet distance
    # amount of times the loop runs is O(log(Frechet distance))
    while not decision(high):
        high *= 2

    # binary search for the minimal leash length that allows the trip, up to the wanted resolution
    while high - low > ALLOWED_ERROR:
        mid = (low + high) / 2
        if decision(mid):
            high = mid
        else:
            low = mid

    return mid, path


def get_distance_matrix(P, Q):
    n, m = len(P), len(Q)
    mat = [[distance(P[i], Q[j]) for j in range(m)] for i in range(n)]
    return mat


