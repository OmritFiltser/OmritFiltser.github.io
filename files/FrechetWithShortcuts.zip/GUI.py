import pygame
import sys
import math
from distance_calculator import distance, discrete_frechet, shortcut_discrete_frechet, get_distance_matrix


# Initialize Pygame
pygame.init()
info = pygame.display.Info()
WIDTH, HEIGHT = info.current_w, info.current_h-60
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Discrete Fréchet Distance Calculator")
font = pygame.font.SysFont(None, 25)

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (220, 20, 60)
BLUE = (30, 144, 255)
DARK_BLUE = (3, 8, 61)
GREY = (180, 180, 180)
GREEN = (0, 240, 0)

# layout
TEXT_LOCATIONS = [(760, 140), (760, 450)]
DRAWING_BOX = pygame.Rect(20, 170, 700, HEIGHT-190)
PLOT_BOXES = [pygame.Rect(760, 170, 220, 230), pygame.Rect(760, 480, 220, 230)]
MATRIX_BOXES = [pygame.Rect(990, 170, WIDTH-1010, 230), pygame.Rect(990, 480, WIDTH-1010, 230)]
LINE_WIDTH = 2
POINT_SIZE = 5
BUTTON_LOCATIONS = [(10, 10), (240, 10)]
INSTRUCTIONS_LOCATION = (15, 70)
FRAME_RATE = 60


# Global Variables
polylines = [[], []]
current_polyline = 0  # polyline currently drown
buttons = []
distance_result = None


# Button Class
class Button:
    def __init__(self, text, pos, callback, color=DARK_BLUE):
        self.text = text
        self.pos = pos
        self.callback = callback  # a function that will be called when the button is pressed
        self.color = color
        self.rect = pygame.Rect(pos[0], pos[1], 220, 50)

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect, border_radius=10)
        label = font.render(self.text, True, WHITE)
        label_rect = label.get_rect(center=self.rect.center)
        screen.blit(label, label_rect)

    def check_click(self, pos):
        if self.rect.collidepoint(pos):
            self.callback()
            return True
        return False


# This class does the graphical representation of a solution (Frechet distance)
class solution_representation:
    def __init__(self, P, Q, func):
        self.P = P
        self.Q = Q
        self.dist, self.path = func(P, Q)
        self.mat = get_distance_matrix(P, Q)

    # casts a polyline to fit in the smaller box
    def cast_polyline(self, line, curve_box):
        def cast_point(point, curve_box):
            return ((point[0]-DRAWING_BOX.left)*curve_box.w/DRAWING_BOX.w+curve_box.left,
                    (point[1]-DRAWING_BOX.top)*curve_box.h/DRAWING_BOX.h+curve_box.top)

        new_polyline = [cast_point(p, curve_box) for p in line]
        return new_polyline

    def draw_solution(self, curve_box, mat_box, text, text_location):
        # Draw curves
        pygame.draw.rect(screen, BLACK, curve_box, LINE_WIDTH)
        casted_P = self.cast_polyline(self.P, curve_box)
        casted_Q = self.cast_polyline(self.Q, curve_box)
        draw_polyline(casted_P, RED)
        draw_polyline(casted_Q, BLUE)

        text1 = font.render(f"{text}: {self.dist:.2f}", True, BLACK)
        screen.blit(text1, text_location)

        # Draw distance matrix as a grid
        n = len(self.mat)
        m = len(self.mat[0])
        cell_w = mat_box.w / m
        cell_h = mat_box.h / n
        font_nums = pygame.font.Font(None, 16)  # Or choose any size or font you like

        for i, j in self.path:
            rect = pygame.Rect(mat_box.left + j * cell_w, mat_box.top + i * cell_h, cell_w, cell_h)
            pygame.draw.rect(screen, GREEN, rect)  # green filled cell
            pygame.draw.line(screen, BLACK, casted_P[i], casted_Q[j], LINE_WIDTH)

        for i in range(n):
            for j in range(m):
                rect = pygame.Rect(mat_box.left + j * cell_w, mat_box.top + i * cell_h, cell_w, cell_h)
                pygame.draw.rect(screen, BLACK, rect, LINE_WIDTH//2)
                text_surface = font_nums.render(f"{self.mat[i][j]:.0f}", True, BLACK)
                text_rect = text_surface.get_rect(center=rect.center)
                screen.blit(text_surface, text_rect)


# called when "redraw" button is pressed
def reset_board():
    global polylines, current_polyline, distance_result
    polylines = [[], []]
    current_polyline = 0
    distance_result = None


# called when "calculate distance" button is pressed
def calculate_distance():
    global distance_result
    if current_polyline == 2:
        d_classic = solution_representation(polylines[0], polylines[1], discrete_frechet)
        d_shortcut = solution_representation(polylines[0], polylines[1], shortcut_discrete_frechet)
        distance_result = (d_classic, d_shortcut)


# Draw the polylines selected so far on the screen
def draw_polyline(points, color):
    if len(points) > 1:
        pygame.draw.lines(screen, color, False, points, LINE_WIDTH)
    for point in points:
        pygame.draw.circle(screen, color, point, POINT_SIZE)


# Create buttons
buttons = [
    Button("Redraw Polylines", BUTTON_LOCATIONS[0], reset_board, DARK_BLUE),
    Button("Calculate Distances", BUTTON_LOCATIONS[1], calculate_distance, DARK_BLUE)
]

# Main loop
clock = pygame.time.Clock()
running = True

while running:
    mouse_pos = pygame.mouse.get_pos()
    screen.fill(WHITE)
    pygame.draw.rect(screen, BLACK, DRAWING_BOX, LINE_WIDTH)

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:  # X button
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:  # mouse click
            button_click = False
            for button in buttons:
                if button.check_click(event.pos):  # one of the buttons was pressed
                    button_click = True

            if not button_click and current_polyline < 2:
                if DRAWING_BOX.collidepoint(event.pos):
                    # first point was clicked
                    if len(polylines[current_polyline]) > 0 and distance(event.pos, polylines[current_polyline][0]) < 10:
                        current_polyline += 1  # finish a polyline
                    else:
                        polylines[current_polyline].append(event.pos)  # add point to polyline

    # Draw polylines
    draw_polyline(polylines[0], RED)
    draw_polyline(polylines[1], BLUE)

    # Draw faded line for current drawing
    if current_polyline < 2 and len(polylines[current_polyline]) > 0:
        pygame.draw.line(screen, GREY, polylines[current_polyline][-1], mouse_pos, 1)

    # Draw buttons
    for button in buttons:
        button.draw(screen)

    # Display instructions
    instruction_lines = [
        "In order to draw a polyline, simply click on the wanted vertices locations.",
        "To finish drawing a polyline, click on its first point.",
        "In shortcut version, skips will be allowed on the blue (second) curve."
    ]
    for i, line in enumerate(instruction_lines):
        text_surface = font.render(line, True, BLACK)
        screen.blit(text_surface, (INSTRUCTIONS_LOCATION[0], INSTRUCTIONS_LOCATION[1] + i * 25))

    # Display calculated distances
    if distance_result:
        distance_result[0].draw_solution(PLOT_BOXES[0], MATRIX_BOXES[0], "Classic Discrete Fréchet Distance", TEXT_LOCATIONS[0])
        distance_result[1].draw_solution(PLOT_BOXES[1], MATRIX_BOXES[1], "Discrete Fréchet Distance With Shortcuts", TEXT_LOCATIONS[1])

    pygame.display.flip()
    clock.tick(FRAME_RATE)

pygame.quit()
sys.exit()
